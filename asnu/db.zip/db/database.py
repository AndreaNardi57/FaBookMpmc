# Source - https://stackoverflow.com/a
# Posted by vaultah, modified by community. See post 'Timeline' for change history
# Retrieved 2026-01-12, License - CC BY-SA 3.0

from pathlib import Path
print('Running' if __name__ == '__main__' else 'Importing', Path(__file__).resolve())

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.engine import URL

from typing import Annotated
## from config import get_settings

PG_DATABASE_URL = URL.create(
    drivername="postgresql+psycopg2",
    username="pescatorello",
    password="acubens@1",
    host="localhost",
    database="mpmcbiblio"
    )


# Create SQLAlchemy engine
engine = create_engine(PG_DATABASE_URL)

# Create SessionLocal class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create Base class for models
Base = declarative_base()

# Dependency to get database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
